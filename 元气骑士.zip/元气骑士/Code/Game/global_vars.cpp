#include "stdafx.h"
#include "global_vars.h"

GameController *gameController;
GameWindow *gameWindow;
ChooseWidget *chooseWidget;
MapWidget *mapWidget;
PhysicsEngine *physicsEngine;
GameDisplayer *gameDisplayer;

int playersNum, myID;
