#include <QtWidgets>
#include <QtNetwork>
#include "ClosedInterval.h"